package com.intellij.psi.css;

/**
 * User: zolotov
 * Date: 4/29/13
 *
 * Marker class for css elements, that consist of single line
 * and should be terminated with semicolon
 */
public interface CssOneLineStatement extends CssElement {
}
