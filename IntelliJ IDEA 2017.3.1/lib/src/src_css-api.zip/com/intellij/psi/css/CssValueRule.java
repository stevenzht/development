package com.intellij.psi.css;

import com.intellij.icons.AllIcons;
import com.intellij.util.Processor;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.util.Collection;

public interface CssValueRule extends CssAtRule {
  Icon ICON = AllIcons.Nodes.Variable;

  Collection<String> getValueNames();

  boolean processValueDeclaringElements(@NotNull final Processor<CssNamedElement> processor);
}
