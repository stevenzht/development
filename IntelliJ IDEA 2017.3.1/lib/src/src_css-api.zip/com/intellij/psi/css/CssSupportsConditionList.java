package com.intellij.psi.css;

public interface CssSupportsConditionList extends CssSupportsCondition {
  CssSupportsCondition[] getConditions();
}
