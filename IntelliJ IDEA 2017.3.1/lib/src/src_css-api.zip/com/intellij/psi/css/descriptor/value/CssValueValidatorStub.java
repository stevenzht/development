package com.intellij.psi.css.descriptor.value;

import com.intellij.psi.PsiElement;

public class CssValueValidatorStub implements CssValueValidator {
  @Override
  public boolean isValid(PsiElement value, CssValueDescriptor valueDescriptor) {
    return true;
  }
}
